# 🔐 SecureChat — Full-Stack Encrypted Chat App

Real-time, end-to-end encrypted messaging built with FastAPI, PostgreSQL, and WebSockets.

---

## ✨ Features

| Feature | Implementation |
|---|---|
| 🔐 E2E Encrypted Messages | AES-256-GCM (client-side) + TLS in transit |
| 📱 Phone OTP Login | SHA-256 hashed OTP + JWT session tokens |
| 📁 File & Image Sharing | Multipart upload → stored server-side |
| 👥 Online/Offline Status | WebSocket presence broadcast |
| ✅ Read Receipts | Real-time delivered/read ticks via WS |
| 🔍 Phone Number Search | Search users by name or phone |
| 🖼️ Profile Picture | Base64 avatar upload on profile setup |
| 🔔 Push Notifications | Browser Notification API + WS toasts |

---

## 🏗️ Architecture

```
┌─────────────────┐     WebSocket      ┌──────────────────────┐
│   Browser       │◄──────────────────►│   FastAPI Backend    │
│  (HTML/JS/CSS)  │                    │   uvicorn + Python   │
└─────────────────┘     REST API       └──────────┬───────────┘
                  ◄──────────────────►            │ SQLAlchemy
                                                  ▼
                                        ┌──────────────────────┐
                                        │   PostgreSQL DB      │
                                        │  users + messages    │
                                        └──────────────────────┘
```

---

## 🚀 Quick Start

### Option A — Docker (Recommended, 1 command)

```bash
# Make sure Docker & Docker Compose are installed
docker compose up --build

# Open browser at:
http://localhost:8000
```

### Option B — Manual Setup

**1. Install PostgreSQL**
```bash
# Ubuntu/Debian
sudo apt install postgresql postgresql-contrib

# macOS
brew install postgresql
```

**2. Create database**
```bash
sudo -u postgres psql -f setup_db.sql
```

**3. Set up Python backend**
```bash
cd backend
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

export DATABASE_URL="postgresql://securechat_user:securechat_pass@localhost:5432/securechat"
export SECRET_KEY="your-super-secret-key-here"

uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

**4. Open in browser**
```
http://localhost:8000
```

---

## 📱 Adding Real SMS OTP

Edit `backend/auth.py` → `send_otp_sms()` function:

### Twilio
```python
from twilio.rest import Client
client = Client(TWILIO_SID, TWILIO_TOKEN)
client.messages.create(to=phone, from_="+1XXXXXXXXXX", body=f"SecureChat OTP: {otp}")
```

### MSG91 (India)
```python
import requests
requests.post("https://api.msg91.com/api/v5/otp",
    json={"mobile": phone, "authkey": "YOUR_KEY", "otp": otp})
```

### Fast2SMS (India, cheapest)
```python
import requests
requests.post("https://www.fast2sms.com/dev/bulkV2",
    headers={"authorization": "YOUR_API_KEY"},
    json={"route":"otp","variables_values":otp,"numbers":phone[3:]})
```

---

## 🌐 Deploy to Production

**Environment variables to set:**
```env
DATABASE_URL=postgresql://user:pass@your-db-host:5432/securechat
SECRET_KEY=your-256-bit-random-secret-key
```

**Recommended hosting:**
- **Backend**: Railway, Render, DigitalOcean App Platform
- **Database**: Supabase (free PostgreSQL), Railway PostgreSQL
- **Domain + SSL**: Cloudflare (free TLS)

---

## 📡 API Reference

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/send-otp` | Send OTP to phone |
| POST | `/api/auth/verify-otp` | Verify OTP, get JWT |
| POST | `/api/auth/setup-profile` | Set name/avatar |
| GET | `/api/auth/me?token=` | Get current user |
| GET | `/api/users/search?phone=` | Search users |
| GET | `/api/messages/history/{id}?token=` | Chat history |
| GET | `/api/messages/contacts?token=` | Contact list |
| POST | `/api/messages/upload?token=` | Upload file |
| WS | `/ws/{token}` | WebSocket connection |

**API Docs (auto-generated):** http://localhost:8000/docs

---

## 🗂️ Project Structure

```
securechat/
├── backend/
│   ├── main.py              # FastAPI app + WebSocket endpoint
│   ├── auth.py              # OTP + JWT authentication
│   ├── messages.py          # Message history + file upload
│   ├── models.py            # SQLAlchemy User + Message models
│   ├── database.py          # PostgreSQL connection
│   ├── websocket_manager.py # WS connection manager
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   └── index.html           # Single-file React-free frontend
├── docker-compose.yml
├── setup_db.sql
├── start.sh
└── README.md
```
