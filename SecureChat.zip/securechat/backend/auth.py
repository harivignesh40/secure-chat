from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import hashlib, random, os, string

from jose import JWTError, jwt
from database import get_db
from models import User

router = APIRouter()

SECRET_KEY = os.getenv("SECRET_KEY", "CHANGE_THIS_IN_PRODUCTION_supersecretkey_2024")
ALGORITHM  = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days

# ── OTP helpers ──────────────────────────────────────
def generate_otp() -> str:
    return ''.join(random.choices(string.digits, k=6))

def hash_otp(otp: str) -> str:
    return hashlib.sha256(otp.encode()).hexdigest()

def send_otp_sms(phone: str, otp: str):
    """
    Plug in your SMS provider here.
    Options:
      - Twilio:   client.messages.create(to=phone, from_=TWILIO_NUM, body=f"Your SecureChat OTP: {otp}")
      - MSG91:    requests.post("https://api.msg91.com/api/v5/otp", ...)
      - Fast2SMS: requests.post("https://www.fast2sms.com/dev/bulkV2", ...)
    For now, the OTP is returned in the response (development mode).
    """
    print(f"[DEV] OTP for {phone}: {otp}")
    return otp  # Remove this return in production!

# ── JWT helpers ───────────────────────────────────────
def create_access_token(user_id: int) -> str:
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    return jwt.encode({"sub": str(user_id), "exp": expire}, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user_ws(token: str, db: Session) -> User | None:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload.get("sub"))
        return db.query(User).filter(User.id == user_id).first()
    except (JWTError, Exception):
        return None

def get_current_user(token: str, db: Session = Depends(get_db)) -> User:
    from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload.get("sub"))
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# ── Schemas ───────────────────────────────────────────
class SendOTPRequest(BaseModel):
    phone: str

class VerifyOTPRequest(BaseModel):
    phone: str
    otp: str

class SetupProfileRequest(BaseModel):
    phone: str
    token: str
    name: str
    status: str = "Hey, I'm using SecureChat!"
    avatar: str | None = None

# ── Routes ────────────────────────────────────────────
@router.post("/send-otp")
def send_otp(req: SendOTPRequest, db: Session = Depends(get_db)):
    phone = req.phone.strip()
    if not phone:
        raise HTTPException(400, "Phone number required")

    otp    = generate_otp()
    expiry = datetime.utcnow() + timedelta(minutes=10)
    dev_otp = send_otp_sms(phone, otp)

    user = db.query(User).filter(User.phone == phone).first()
    if user:
        user.otp_hash   = hash_otp(otp)
        user.otp_expiry = expiry
    else:
        user = User(phone=phone, name="", otp_hash=hash_otp(otp), otp_expiry=expiry)
        db.add(user)
    db.commit()

    resp = {"message": "OTP sent", "phone": phone}
    if dev_otp:  # Remove in production
        resp["dev_otp"] = dev_otp
    return resp

@router.post("/verify-otp")
def verify_otp(req: VerifyOTPRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.phone == req.phone).first()
    if not user:
        raise HTTPException(400, "Phone not registered")
    if user.otp_expiry < datetime.utcnow():
        raise HTTPException(400, "OTP expired. Please request a new one.")
    if user.otp_hash != hash_otp(req.otp):
        raise HTTPException(400, "Invalid OTP")

    user.otp_hash   = None
    user.otp_expiry = None
    db.commit()

    token = create_access_token(user.id)
    is_new = not user.name
    return {"token": token, "is_new_user": is_new, "user_id": user.id}

@router.post("/setup-profile")
def setup_profile(req: SetupProfileRequest, db: Session = Depends(get_db)):
    user = get_current_user(req.token, db)
    user.name   = req.name.strip()
    user.status = req.status.strip()
    user.avatar = req.avatar
    db.commit()
    return {"message": "Profile updated", "user": {
        "id": user.id, "name": user.name,
        "phone": user.phone, "status": user.status, "avatar": user.avatar
    }}

@router.get("/me")
def get_me(token: str, db: Session = Depends(get_db)):
    user = get_current_user(token, db)
    return {"id": user.id, "name": user.name, "phone": user.phone,
            "status": user.status, "avatar": user.avatar}
