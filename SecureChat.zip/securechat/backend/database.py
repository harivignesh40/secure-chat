from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# PostgreSQL connection — set DATABASE_URL in environment
# Format: postgresql://user:password@localhost:5432/securechat
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://securechat_user:securechat_pass@localhost:5432/securechat"
)

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
