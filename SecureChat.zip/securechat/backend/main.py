from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import json
import asyncio
from typing import Optional
from datetime import datetime

from database import engine, Base, get_db
from models import User, Message
from auth import router as auth_router, get_current_user_ws
from messages import router as messages_router
from websocket_manager import manager
from sqlalchemy.orm import Session

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="SecureChat API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(auth_router, prefix="/api/auth", tags=["auth"])
app.include_router(messages_router, prefix="/api/messages", tags=["messages"])

@app.get("/api/users/search")
def search_users(phone: str, db: Session = Depends(get_db)):
    users = db.query(User).filter(
        User.phone.contains(phone),
        User.is_active == True
    ).limit(10).all()
    return [{"id": u.id, "name": u.name, "phone": u.phone,
             "status": u.status, "avatar": u.avatar,
             "online": manager.is_online(u.id)} for u in users]

@app.get("/api/users/{user_id}")
def get_user(user_id: int, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.id == user_id).first()
    if not u:
        raise HTTPException(404, "User not found")
    return {"id": u.id, "name": u.name, "phone": u.phone,
            "status": u.status, "avatar": u.avatar,
            "online": manager.is_online(u.id)}

@app.websocket("/ws/{token}")
async def websocket_endpoint(websocket: WebSocket, token: str, db: Session = Depends(get_db)):
    user = get_current_user_ws(token, db)
    if not user:
        await websocket.close(code=4001)
        return

    await manager.connect(websocket, user.id)
    
    # Notify contacts that user is online
    await manager.broadcast_status(user.id, True, db)

    try:
        while True:
            data = await websocket.receive_text()
            payload = json.loads(data)
            msg_type = payload.get("type")

            if msg_type == "message":
                # Save to DB
                msg = Message(
                    sender_id=user.id,
                    receiver_id=payload["to"],
                    content=payload["content"],
                    msg_type=payload.get("msg_type", "text"),
                    file_url=payload.get("file_url"),
                    timestamp=datetime.utcnow(),
                    is_read=False
                )
                db.add(msg)
                db.commit()
                db.refresh(msg)

                # Send to recipient if online
                out = {
                    "type": "message",
                    "id": msg.id,
                    "from": user.id,
                    "from_name": user.name,
                    "from_avatar": user.avatar,
                    "content": payload["content"],
                    "msg_type": payload.get("msg_type", "text"),
                    "file_url": payload.get("file_url"),
                    "timestamp": msg.timestamp.isoformat(),
                    "status": "delivered"
                }
                await manager.send_to_user(payload["to"], out)
                # Confirm delivery to sender
                await manager.send_to_user(user.id, {
                    "type": "delivered", "msg_id": msg.id
                })

            elif msg_type == "read":
                # Mark messages as read
                db.query(Message).filter(
                    Message.id.in_(payload.get("msg_ids", [])),
                    Message.receiver_id == user.id
                ).update({"is_read": True}, synchronize_session=False)
                db.commit()
                # Notify sender
                for mid in payload.get("msg_ids", []):
                    m = db.query(Message).filter(Message.id == mid).first()
                    if m:
                        await manager.send_to_user(m.sender_id, {
                            "type": "read", "msg_id": mid
                        })

            elif msg_type == "typing":
                await manager.send_to_user(payload["to"], {
                    "type": "typing",
                    "from": user.id,
                    "from_name": user.name,
                    "is_typing": payload.get("is_typing", False)
                })

    except WebSocketDisconnect:
        manager.disconnect(user.id)
        await manager.broadcast_status(user.id, False, db)

# Serve frontend
app.mount("/", StaticFiles(directory="../frontend", html=True), name="frontend")
