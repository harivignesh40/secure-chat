from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy import or_, and_
from database import get_db
from models import Message, User
from auth import get_current_user
import base64, uuid, os

router = APIRouter()

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.get("/history/{other_user_id}")
def get_history(other_user_id: int, token: str, limit: int = 50,
                db: Session = Depends(get_db)):
    me = get_current_user(token, db)
    msgs = db.query(Message).filter(
        or_(
            and_(Message.sender_id == me.id,   Message.receiver_id == other_user_id),
            and_(Message.sender_id == other_user_id, Message.receiver_id == me.id)
        )
    ).order_by(Message.timestamp.asc()).limit(limit).all()

    # Mark received messages as read
    unread_ids = [m.id for m in msgs if m.receiver_id == me.id and not m.is_read]
    if unread_ids:
        db.query(Message).filter(Message.id.in_(unread_ids)).update(
            {"is_read": True}, synchronize_session=False)
        db.commit()

    return [_msg_out(m, me.id) for m in msgs]

@router.get("/contacts")
def get_contacts(token: str, db: Session = Depends(get_db)):
    """Returns list of users this user has chatted with, with last message."""
    from websocket_manager import manager
    me = get_current_user(token, db)

    # Get distinct conversation partners
    from sqlalchemy import func
    subq = db.query(
        func.greatest(Message.sender_id, Message.receiver_id).label("uid1"),
        func.least(Message.sender_id, Message.receiver_id).label("uid2"),
        func.max(Message.id).label("last_id")
    ).filter(
        or_(Message.sender_id == me.id, Message.receiver_id == me.id)
    ).group_by("uid1", "uid2").subquery()

    result = []
    seen_users = set()
    last_msgs = db.query(Message).join(subq, Message.id == subq.c.last_id).all()

    for msg in sorted(last_msgs, key=lambda m: m.timestamp, reverse=True):
        other_id = msg.sender_id if msg.receiver_id == me.id else msg.receiver_id
        if other_id in seen_users:
            continue
        seen_users.add(other_id)
        other = db.query(User).filter(User.id == other_id).first()
        if not other:
            continue
        unread = db.query(Message).filter(
            Message.sender_id == other_id,
            Message.receiver_id == me.id,
            Message.is_read == False
        ).count()
        result.append({
            "user": {"id": other.id, "name": other.name, "phone": other.phone,
                     "status": other.status, "avatar": other.avatar,
                     "online": manager.is_online(other.id)},
            "last_message": _msg_out(msg, me.id),
            "unread_count": unread
        })
    return result

@router.post("/upload")
async def upload_file(token: str, file: UploadFile = File(...),
                      db: Session = Depends(get_db)):
    me = get_current_user(token, db)
    ext  = file.filename.split(".")[-1].lower()
    fname = f"{uuid.uuid4()}.{ext}"
    path  = os.path.join(UPLOAD_DIR, fname)
    content = await file.read()
    with open(path, "wb") as f:
        f.write(content)
    size = len(content)
    return {
        "file_url": f"/uploads/{fname}",
        "filename": file.filename,
        "size": f"{round(size/1024,1)}KB" if size < 1048576 else f"{round(size/1048576,1)}MB",
        "msg_type": "image" if file.content_type.startswith("image/") else "file"
    }

def _msg_out(m: Message, my_id: int):
    return {
        "id": m.id,
        "from": m.sender_id,
        "to": m.receiver_id,
        "content": m.content,
        "msg_type": m.msg_type,
        "file_url": m.file_url,
        "timestamp": m.timestamp.isoformat(),
        "is_read": m.is_read,
        "status": "read" if m.is_read else "delivered"
    }
