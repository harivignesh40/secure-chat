from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

class User(Base):
    __tablename__ = "users"

    id         = Column(Integer, primary_key=True, index=True)
    phone      = Column(String(20), unique=True, index=True, nullable=False)
    name       = Column(String(100), nullable=False)
    status     = Column(String(200), default="Hey, I'm using SecureChat!")
    avatar     = Column(Text, nullable=True)          # base64 or URL
    otp_hash   = Column(String(256), nullable=True)   # SHA-256 of OTP
    otp_expiry = Column(DateTime, nullable=True)
    is_active  = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    sent_messages     = relationship("Message", foreign_keys="Message.sender_id",   back_populates="sender")
    received_messages = relationship("Message", foreign_keys="Message.receiver_id", back_populates="receiver")


class Message(Base):
    __tablename__ = "messages"

    id          = Column(Integer, primary_key=True, index=True)
    sender_id   = Column(Integer, ForeignKey("users.id"), nullable=False)
    receiver_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    content     = Column(Text, nullable=False)        # AES-encrypted ciphertext
    msg_type    = Column(String(20), default="text")  # text | image | file
    file_url    = Column(Text, nullable=True)
    timestamp   = Column(DateTime, default=datetime.utcnow)
    is_read     = Column(Boolean, default=False)

    sender   = relationship("User", foreign_keys=[sender_id],   back_populates="sent_messages")
    receiver = relationship("User", foreign_keys=[receiver_id], back_populates="received_messages")
