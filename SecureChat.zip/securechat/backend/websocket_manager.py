from fastapi import WebSocket
from typing import Dict
import json

class ConnectionManager:
    def __init__(self):
        self.active: Dict[int, WebSocket] = {}  # user_id -> websocket

    async def connect(self, ws: WebSocket, user_id: int):
        await ws.accept()
        self.active[user_id] = ws

    def disconnect(self, user_id: int):
        self.active.pop(user_id, None)

    def is_online(self, user_id: int) -> bool:
        return user_id in self.active

    async def send_to_user(self, user_id: int, data: dict):
        ws = self.active.get(user_id)
        if ws:
            try:
                await ws.send_text(json.dumps(data))
            except Exception:
                self.disconnect(user_id)

    async def broadcast_status(self, user_id: int, online: bool, db):
        """Notify all of this user's contacts about online/offline status."""
        from models import Message, User
        from sqlalchemy import or_
        contacts = db.query(Message.sender_id, Message.receiver_id).filter(
            or_(Message.sender_id == user_id, Message.receiver_id == user_id)
        ).distinct().all()
        notified = set()
        for row in contacts:
            other = row.sender_id if row.receiver_id == user_id else row.receiver_id
            if other not in notified and other != user_id:
                notified.add(other)
                await self.send_to_user(other, {
                    "type": "status",
                    "user_id": user_id,
                    "online": online
                })

manager = ConnectionManager()
