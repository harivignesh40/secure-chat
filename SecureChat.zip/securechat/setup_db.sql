-- Run this in PostgreSQL to set up the SecureChat database

-- Create database
CREATE DATABASE securechat;

-- Create user
CREATE USER securechat_user WITH PASSWORD 'securechat_pass';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE securechat TO securechat_user;

-- Connect to securechat database, then run:
\c securechat
GRANT ALL ON SCHEMA public TO securechat_user;

-- Tables are auto-created by SQLAlchemy on first run
-- But you can verify with:
-- \dt
