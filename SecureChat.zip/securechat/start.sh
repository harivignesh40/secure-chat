#!/bin/bash
# SecureChat - One-click startup script

echo "🔐 Starting SecureChat..."

# ─── Check PostgreSQL ───────────────────────────────────────
if ! command -v psql &>/dev/null; then
    echo "❌ PostgreSQL not found. Install with:"
    echo "   Ubuntu/Debian: sudo apt install postgresql postgresql-contrib"
    echo "   macOS:         brew install postgresql"
    exit 1
fi

# Start PostgreSQL if not running
sudo service postgresql start 2>/dev/null || pg_ctl start 2>/dev/null

# Setup database (first run only)
psql -U postgres -c "SELECT 1 FROM pg_database WHERE datname='securechat'" | grep -q 1 || {
    echo "📦 Setting up database..."
    psql -U postgres -f setup_db.sql
}

# ─── Backend ───────────────────────────────────────────────
cd backend

# Install dependencies
if [ ! -d "venv" ]; then
    echo "📦 Creating Python virtual environment..."
    python3 -m venv venv
fi
source venv/bin/activate
pip install -r requirements.txt -q

# Set environment variables
export DATABASE_URL="postgresql://securechat_user:securechat_pass@localhost:5432/securechat"
export SECRET_KEY="your-super-secret-jwt-key-change-this"

echo "🚀 Starting FastAPI server on http://localhost:8000"
uvicorn main:app --host 0.0.0.0 --port 8000 --reload &
BACKEND_PID=$!

cd ..

echo ""
echo "✅ SecureChat is running!"
echo ""
echo "   🌐 Open in browser: http://localhost:8000"
echo "   📡 API docs:        http://localhost:8000/docs"
echo "   🔌 WebSocket:       ws://localhost:8000/ws/{token}"
echo ""
echo "   Press Ctrl+C to stop"
echo ""

# Wait for Ctrl+C
trap "kill $BACKEND_PID; echo ''; echo '🔒 SecureChat stopped.'; exit" INT
wait $BACKEND_PID
